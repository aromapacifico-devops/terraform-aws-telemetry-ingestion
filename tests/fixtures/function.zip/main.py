def handler(event, context):
    return {"batchItemFailures": []}
